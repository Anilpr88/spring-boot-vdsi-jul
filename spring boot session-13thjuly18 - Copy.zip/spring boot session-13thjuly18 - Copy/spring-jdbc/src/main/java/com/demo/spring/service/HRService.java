package com.demo.spring.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.demo.spring.dao.EmployeeDao;
import com.demo.spring.entity.Employee;

@Service
public class HRService {
	
	@Autowired
	private EmployeeDao employeeDao;
	
	
	public String addEmployee(int id,String name,String city,double salary){
		
		String response = employeeDao.save(new Employee(id, name, city, salary));
		return response;
	}
	
	
	public void searchEmpDetails(int empid){
		Employee e = employeeDao.findById(empid);
		System.out.println(" Emp details : "+e.getEmpId() + " "+e.getName()+" "+e.getCity());
	}
	
	
	public void saveGroup(List<Employee> employee){
		String msg = employeeDao.saveBatch(employee);
		System.out.println("Success");
	}

}
