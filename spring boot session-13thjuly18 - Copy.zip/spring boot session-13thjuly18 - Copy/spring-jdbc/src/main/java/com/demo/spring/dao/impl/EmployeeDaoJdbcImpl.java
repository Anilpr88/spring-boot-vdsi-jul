package com.demo.spring.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.management.RuntimeErrorException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.demo.spring.dao.EmployeeDao;
import com.demo.spring.entity.Employee;

@Repository
public class EmployeeDaoJdbcImpl implements EmployeeDao{

	@Autowired
	JdbcTemplate jt;
	
	
	@Override
	public String save(Employee emp) {
		
		
		int count = jt.update(new PreparedStatementCreator() {
			
			@Override
			public PreparedStatement createPreparedStatement(Connection conn) throws SQLException {
				
				PreparedStatement pst = conn.prepareStatement("insert into emp(empno,name,address,salary) values (?,?,?,?)");
				pst.setInt(1, emp.getEmpId());
				pst.setString(2, emp.getName());
				pst.setString(3, emp.getCity());
				pst.setDouble(4, emp.getSalary());
				return pst;
			}
		});
		
		if(count ==1)
			 return "Saved";
		
		return "Failed";		
	
	}

	@Override
	public String delete(int empId) {
		
		int count = jt.update(new PreparedStatementCreator() {
			
			@Override
			public PreparedStatement createPreparedStatement(Connection conn) throws SQLException {
				
				PreparedStatement pst = conn.prepareStatement(" Delete * from emp where empid = ?");
				
				pst.setInt(1, empId);
				return pst;
			}
		});
		if(count ==1)
			 return "Deleted";
		
		return "Failed";
	}

	@Override
	public String update(Employee e) {
		
		int count = jt.update(new PreparedStatementCreator() {
			
			@Override
			public PreparedStatement createPreparedStatement(Connection conn) throws SQLException {
				
				PreparedStatement pst = conn.prepareStatement("updtae  emp set name=?,address=?,salary=? where empno = "+e.getEmpId());
				
				pst.setString(1, e.getName());
				pst.setString(2, e.getCity());
				pst.setDouble(3, e.getSalary());
				return pst;
			}
		});
		
		if(count ==1)
			 return "Updated";
		
		return "Failed";
	}

	@Override
	public Employee findById(int id) {

		Employee emp = null;
		try{
			
		
		 emp = jt.queryForObject("select * from emp where empno="+id, new RowMapper<Employee>(){

			@Override
			public Employee mapRow(ResultSet rs, int index) throws SQLException {
				
				return new Employee(rs.getInt("EMPNO"),rs.getString("NAME"),rs.getString("ADDRESS"),rs.getDouble("SALARY"));
			}
			
		});
		}
		catch(Exception e){
			
			throw new RuntimeErrorException(null, "No Employee by this ID");
		}
		
		return emp;
	}

	@Override
	public List<Employee> getAll() {
		
		List<Employee> empList = jt.query("select * from emp", new RowMapper<Employee>(){

			@Override
			public Employee mapRow(ResultSet rs, int index) throws SQLException {
				
				return new Employee(rs.getInt("EMPNO"),rs.getString("NAME"),rs.getString("ADDRESS"),rs.getDouble("SALARY"));
			}
			
		});
		return empList;
	}

	@Override
	@Transactional(propagation=Propagation.REQUIRED)
	public String saveBatch(List<Employee> emplist) {
	
		for(Employee e : emplist){
			save(e);
		}
		return "Success";
	}

}
