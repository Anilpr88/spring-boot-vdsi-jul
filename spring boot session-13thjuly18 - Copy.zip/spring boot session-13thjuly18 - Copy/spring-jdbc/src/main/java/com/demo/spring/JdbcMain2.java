package com.demo.spring;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

import org.springframework.jdbc.core.RowMapper;

import com.demo.spring.entity.Employee;

public class JdbcMain2 {

	public static void main(String[] args) {
		
		ApplicationContext ctx = new AnnotationConfigApplicationContext(DaoConfig.class);
		JdbcTemplate jt  = (JdbcTemplate) ctx.getBean("jt");
	
		List<Employee> empList = jt.query("select * from emp", new RowMapper<Employee>(){

			@Override
			public Employee mapRow(ResultSet rs, int index) throws SQLException {
				// TODO Auto-generated method stub
				return new Employee(rs.getInt("EMPNO"),rs.getString("NAME"),rs.getString("ADDRESS"),rs.getDouble("SALARY"));
			}
			
		});
		
		for(Employee e : empList)
		{
			System.out.println(e.getName() + "  " + e.getSalary());
		}
		
		
		Employee emp = jt.queryForObject("select * from emp where empno="+106, new RowMapper<Employee>(){

			@Override
			public Employee mapRow(ResultSet rs, int index) throws SQLException {
				// TODO Auto-generated method stub
				return new Employee(rs.getInt("EMPNO"),rs.getString("NAME"),rs.getString("ADDRESS"),rs.getDouble("SALARY"));
			}
			
		});
		System.out.println("****************");
		System.out.println(emp.getName() + "  " + emp.getSalary());
	
	}

}
