package com.demo.spring.dao;

import java.util.List;

import com.demo.spring.entity.Employee;

public interface EmployeeDao {
	
	public String save(Employee emp);
	public String delete(int empId);
	public String update(Employee e);
	public Employee findById(int id);
	public List<Employee> getAll();
	public String saveBatch(List<Employee> emplist);
	

}
