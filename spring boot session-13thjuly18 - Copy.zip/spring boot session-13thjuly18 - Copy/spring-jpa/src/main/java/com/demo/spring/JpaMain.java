package com.demo.spring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.demo.spring.service.HRService;

public class JpaMain {
	
	public static void main(String args[])
	{
		
		ApplicationContext ctx = new AnnotationConfigApplicationContext(DaoConfig.class);
		HRService service = (HRService) ctx.getBean(HRService.class);
		
		service.addEmployee(200, "Yalmathi", "Cbe", 100000);
		
		service.searchEmpDetails(200);
	}

}
