package com.demo.spring.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.demo.spring.dao.EmployeeDao;
import com.demo.spring.entity.Employee;

@Repository
public class EmployeeDaoJpaImpl implements EmployeeDao {

	@PersistenceContext
	EntityManager em;
	
	@Override
	@Transactional
	public String save(Employee emp) {
		em.persist(emp);
		return "Save";
	}

	@Override
	public String delete(int empId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String update(Employee e) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Employee findById(int id) {
		Employee emp = em.find(Employee.class, id);
		return emp;
	}

	@Override
	public List<Employee> getAll() {
	
		
		Query query = em.createQuery("select e from Employee e");
		List<Employee> empList = query.getResultList();
		return empList;
	}

	@Override
	public String saveBatch(List<Employee> emplist) {
		
		for(Employee e : emplist)
		{
			em.persist(e);
		}
		
		return "success";
	}

}
