package com.demo.spring.dao.impl;

import org.springframework.stereotype.Repository;

import com.demo.spring.dao.EmployeeDao;
import com.demo.spring.entity.Employee;

@Repository()
public class EmployeeDaoImpl implements EmployeeDao{

	@Override
	public String save(Employee emp) {
		
		return "JDBC; Emp Save with :: "+emp.getEmpId();
	}

}
