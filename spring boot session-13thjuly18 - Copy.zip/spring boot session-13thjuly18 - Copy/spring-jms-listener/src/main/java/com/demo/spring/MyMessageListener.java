package com.demo.spring;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.TextMessage;

import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;
@Component
public class MyMessageListener {
	
	@JmsListener(destination="MyQueue",containerFactory="factory")
	public void getMessage(Message msg) throws JMSException
	{
		TextMessage tm = (TextMessage) msg;
		
		System.out.println("Msg received : "+tm.getText());
	}

}
