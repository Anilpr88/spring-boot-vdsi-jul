package com.demo.spring.dao.impl;

import com.demo.spring.dao.EmployeeDao;
import com.demo.spring.entity.Employee;

public class EmployeeDaoImpl implements EmployeeDao{

	@Override
	public String save(Employee emp) {
		
		return "JDBC; Emp Save with :: "+emp.getEmpId();
	}

}
