package com.demo.spring.dao;

import com.demo.spring.entity.Employee;

public interface EmployeeDao {
	
	public String save(Employee emp);

}
