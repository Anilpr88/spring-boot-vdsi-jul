package com.demo.spring.service;

import com.demo.spring.dao.EmployeeDao;
import com.demo.spring.entity.Employee;

public class HRService {
	
	
	private EmployeeDao employeeDao;
	
	
	public HRService() {
		// TODO Auto-generated constructor stub
	}
	
	public HRService(EmployeeDao employeeDao) {
		super();
		this.employeeDao = employeeDao;
	}




	public void setEmployeeDao(EmployeeDao employeeDao) {
		this.employeeDao = employeeDao;
	}


	public String addEmployee(int empId,String name, String address,double salary){
		
		String resp = employeeDao.save(new Employee(empId, name,  address, salary));
		return resp;
		
	}

}
