package com.demo.spring.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.demo.spring.service.HRService;

public class Test {
	
	public static void main(String[] args){
		
		ApplicationContext ctx = new ClassPathXmlApplicationContext("context.xml");
		
		HRService hrService = (HRService) ctx.getBean("hr");
		
		String resp = hrService.addEmployee(1203, "Parthi", "Coimbatore", 10000);
		System.out.println(resp);
	}
}
