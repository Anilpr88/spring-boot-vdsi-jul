package com.demo.spring;

import org.springframework.stereotype.Service;

@Service
public class Singer implements Performer{

	@Override
	public void perform() throws PerformerException {
	
		try{
			//throw new PerformerException();
			System.out.println("Singer is Singing");
		} catch(Exception e){
			System.out.println("In Catch block");
			e.printStackTrace();
			throw e;
		}
		finally{
			System.out.println("In Finally block");
		}
		
		//
	}

}
