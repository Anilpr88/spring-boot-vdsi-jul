package com.spring.demo;

import org.apache.commons.codec.binary.Base64;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

public class GetClient {
	
	
	public static void main(String[] args)
	{
		
		RestTemplate rt = new RestTemplate();
		
		
		
		
		
		ResponseEntity<String> resp = rt.getForEntity("http://localhost:8080/emprestapp/emp?empid=106", String.class);
		
		System.out.println(resp.getBody());
		
	}

}
