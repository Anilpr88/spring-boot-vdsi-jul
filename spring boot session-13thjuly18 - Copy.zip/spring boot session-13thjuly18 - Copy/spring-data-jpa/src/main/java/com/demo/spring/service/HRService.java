package com.demo.spring.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.spring.EmployeeRepository;
import com.demo.spring.entity.Employee;

@Service
public class HRService {
	
	@Autowired
	EmployeeRepository repo;
	
	
	public String addEmployee(int id,String name,String city,double salary){
		
		Employee emp = repo.save(new Employee(id, name, city, salary));
		return "Saved";
	}
	
	
	public void searchEmpDetails(int empid){
		Optional<Employee> o = repo.findById(empid);
		Employee e = o.get();
		System.out.println(" Emp details : "+e.getEmpId() + " "+e.getName()+" "+e.getCity());
	}
	
	
	public void saveGroup(List<Employee> empList){
		repo.saveAll(empList);
	}

}
