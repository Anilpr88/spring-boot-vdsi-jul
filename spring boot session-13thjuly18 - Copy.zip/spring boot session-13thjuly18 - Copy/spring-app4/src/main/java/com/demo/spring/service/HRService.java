package com.demo.spring.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.demo.spring.dao.EmployeeDao;
import com.demo.spring.entity.Employee;

@Service
public class HRService {
	
	@Autowired
	@Qualifier("jpa")
	private EmployeeDao employeeDao;
	
	
	public HRService() {
		// TODO Auto-generated constructor stub
	}
	


	public String addEmployee(int empId,String name, String address,double salary){
		
		String resp = employeeDao.save(new Employee(empId, name,  address, salary));
		return resp;
		
	}

}
