package com.demo.spring.dao.impl;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.demo.spring.dao.EmployeeDao;
import com.demo.spring.entity.Employee;

@Repository()
@Qualifier("jpa")
public class EmployeeJPAImpl implements EmployeeDao{

	@Override
	public String save(Employee emp) {
		
		return "JPA; Emp Save with :: "+emp.getEmpId();
	}

}
