package com.demo.spring;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;

public class MessageSender {
	
	public MessageSender() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		
		
		ApplicationContext ctx = new AnnotationConfigApplicationContext(JmsConfig.class);
		
		JmsTemplate jt = ctx.getBean(JmsTemplate.class);
		
		jt.send(new MessageCreator() {
			
			@Override
			public Message createMessage(Session arg0) throws JMSException {
				// TODO Auto-generated method stub
				
				TextMessage tm = arg0.createTextMessage();
				tm.setText("Message19");
				
				return tm;
			}
		});
		
		System.out.println("Message sent");
	}

}
