package com.demo.spring;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {
	
	
	
	public BCryptPasswordEncoder passwordEnc(){
		
		return new BCryptPasswordEncoder();
	}
	
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		
		http
		.authorizeRequests()
		.antMatchers("/greet/**").permitAll()
		.antMatchers("/app/**").hasAnyRole("USER")
		.and().httpBasic()
		.and().csrf().disable();
	}
	
	
	//memmory store
	/*@Autowired
	public void configureGlobal(AuthenticationManagerBuilder auth)throws Exception{
		
		auth.inMemoryAuthentication().passwordEncoder(passwordEnc()).withUser("parthi").password("$2a$10$nS4/91TpwMiMgHzo5O/T2..yQbaVg/Z2C.1BALBj/wa21BqTkvEmG").roles("USER").disabled(true);
		auth.inMemoryAuthentication().passwordEncoder(passwordEnc()).withUser("yal").password("$2a$10$/RznOUrlXmKzPcZhSsNxEuT0rnMLrWhM/KlndC7FGeDXhHzLJZXKi").roles("ADMIN");
		auth.inMemoryAuthentication().passwordEncoder(passwordEnc()).withUser("tanu").password("$2a$10$191Dhk1LYmVqrb8eHAC1oOL5iinVHhyzB6UrJS8kT0sjgIwAhzBFW").roles("USER");
		
		
	}*/
	
	@Autowired
	public void configureGlobal(AuthenticationManagerBuilder auth,DataSource ds) throws Exception{
		
		auth.jdbcAuthentication().dataSource(ds)
		    .passwordEncoder(passwordEnc())
		    .usersByUsernameQuery("select username,password,enabled from users where username=?")
		    .authoritiesByUsernameQuery("select username,authority from authorities where username=?");
	}
}
