package com.demo.spring.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.demo.spring.EmployeeRepository;
import com.demo.spring.entity.Employee;

@Controller
public class EmployeeController {
	
	@Autowired
	EmployeeRepository repo;

	@RequestMapping(path = "/home", method = RequestMethod.GET)
	public String getPage()
	{
		return "registerEmp";
	}
	
	
	@RequestMapping(path = "/store",method=RequestMethod.POST)
	public ModelAndView storeEmp(@RequestParam("id") int id,
								 @RequestParam("name") String name,
								 @RequestParam("city") String city,
								 @RequestParam("salary") double salary){
		
		ModelAndView mv = new ModelAndView();
		Optional<Employee> o = repo.findById(id);
				
		
		if(!o.isPresent()){
			Employee e = repo.save(new Employee(id, name, city, salary));
			mv.addObject("emp",e);
			mv.setViewName("Success");
		}else{
			mv.addObject("error", "Employee could not store");
			mv.setViewName("Failure");
		}
		
		return mv;		
		
	}
}
