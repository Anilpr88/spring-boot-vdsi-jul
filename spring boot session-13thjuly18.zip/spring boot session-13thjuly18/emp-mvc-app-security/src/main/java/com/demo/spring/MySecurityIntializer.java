package com.demo.spring;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

public class MySecurityIntializer extends AbstractSecurityWebApplicationInitializer {

}
